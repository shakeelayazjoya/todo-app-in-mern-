import React, { useState } from "react";
import "./signup.css";
import HeadingComp from "./HeadingComp";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const Signup = () => {
  const history = useNavigate();
  const [input, setInput] = useState({
    email: "",
    username: "",
    password: "",
  });

  const change = (e) => {
    const { name, value } = e.target; // Correct destructuring
    setInput({ ...input, [name]: value });
  };

  const submit = async (e) => {
    e.preventDefault(); // Prevent default form submission
    try {
      const response = await axios.post(
        `${window.location.origin}/api/v1/register`,

        input
      );

      if (response.data.message === "User already exists") {
        alert(response.data.message);
      } else {
        alert(response.data.message);
        // Optionally redirect or perform any other action upon successful signup
        history("/signin"); // Redirect to login page after successful signup
      }
    } catch (error) {
      console.error(error); // Log the error to the console
      alert("An error occurred. Please try again."); // Show an alert for errors
    }

    console.log(input);
    setInput({
      email: "",
      username: "",
      password: "",
    });
  };

  return (
    <div className="signup">
      <div className="container">
        <div className="row">
          <div className="col-lg-8 column d-flex justify-content-center align-items-center">
            <div className="d-flex flex-column w-100 p-3">
              <input
                className="p-2 my-3 input-signup"
                type="email"
                name="email" // Correct name attribute
                placeholder="Enter Your Email"
                onChange={change}
                value={input.email}
              />
              <input
                className="p-2 my-3 input-signup"
                type="text"
                name="username" // Correct name attribute
                placeholder="Enter Your Username"
                onChange={change}
                value={input.username} // Correct value
              />
              <input
                className="p-2 my-3 input-signup"
                type="password"
                name="password" // Add name attribute
                placeholder="Enter Your Password"
                onChange={change}
                value={input.password}
              />
              <button className="btn-signup p-2" onClick={submit}>
                Sign Up
              </button>
            </div>
          </div>
          <div className="col-lg-4 column col-left d-lg-flex justify-content-center align-items-center d-none">
            <HeadingComp first="Sign" second="Up" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Signup;
