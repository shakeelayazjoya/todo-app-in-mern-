import React, { useState, useEffect } from "react";
import "./todo.css";
import TodoCards from "./TodoCards";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import Update from "./Update";
import axios from "axios";

const Todo = () => {
  const [userId, setUserId] = useState(sessionStorage.getItem("id")); // State for user ID
  const [input, setInput] = useState({ title: "", body: "" });
  const [array, setArray] = useState([]); // State for tasks
  const [isUpdating, setIsUpdating] = useState(false); // To track if we are updating
  const [updateIndex, setUpdateIndex] = useState(null); // Index of the task being updated

  const change = (e) => {
    const { name, value } = e.target;
    setInput((prevState) => ({ ...prevState, [name]: value }));
  };

  const submit = async () => {
    if (input.title === "" || input.body === "") {
      toast.error("Title and Body are required");
      return;
    }

    if (userId) {
      try {
        const response = await axios.post(
          `${window.location.origin}/api/v2/addTask`,
          {
            title: input.title,
            body: input.body,
            id: userId,
          }
        );

        // Add the new task to the array state
        setArray((prevArray) => [
          ...prevArray,
          { title: input.title, body: input.body }, // Adjust this according to your API response
        ]);

        // Clear the input fields
        setInput({ title: "", body: "" });
        toast.success("Task added successfully");
      } catch (error) {
        console.error("Error adding task:", error);
        toast.error("Error adding task. Please try again.");
      }
    } else {
      toast.error("Please sign in to add tasks.");
    }
  };

  const del = (index) => {
    setArray((prevArray) => prevArray.filter((_, i) => i !== index));
  };

  const handleUpdate = (index) => {
    setInput(array[index]); // Set input for updating
    setIsUpdating(true); // Set updating mode
    setUpdateIndex(index); // Save index of the task being updated
  };

  const updateTask = () => {
    const updatedArray = [...array];
    updatedArray[updateIndex] = input; // Update the task at the specific index
    setArray(updatedArray);
    setIsUpdating(false); // Exit update mode
    setInput({ title: "", body: "" }); // Clear input fields
  };

  const closeUpdate = () => {
    setIsUpdating(false);
    setInput({ title: "", body: "" }); // Clear input fields on close
  };

  const fetchTasks = async () => {
    console.log("Fetched ID:", userId); // Log the ID
    if (!userId) {
      console.error("No ID found in sessionStorage.");
      return; // Exit if there's no ID
    }

    try {
      const response = await axios.get(
        `http://localhost:1000/api/v2/getTask/${userId}`
      );
      if (Array.isArray(response.data.tasks)) {
        setArray(response.data.tasks); // Set tasks to state
      } else {
        console.error("Fetched data is not an array:", response.data);
        toast.error("Unexpected data format received.");
      }
    } catch (error) {
      console.error("Error fetching tasks:", error); // Log any fetch errors
    }
  };

  useEffect(() => {
    fetchTasks(); // Fetch tasks when component mounts or userId changes
  }, [userId]); // Depend on userId

  return (
    <>
      <div className="todo">
        <ToastContainer />
        <div className="todo-main container d-flex justify-content-center align-items-center my-4 flex-column">
          <div className="d-flex flex-column todo-inputs-div w-lg-50 w-100 p-1">
            <input
              type="text"
              placeholder="TITLE"
              className="my-2 p-2 todo-inputs"
              value={input.title}
              name="title"
              onChange={change}
            />
            <textarea
              placeholder="BODY"
              className="p-2 todo-inputs"
              name="body"
              value={input.body}
              onChange={change}
            />
          </div>
          <div className="w-50 w-100 d-flex justify-content-end my-3">
            <button className="home-btn px-2 py-1" onClick={submit}>
              Add
            </button>
          </div>
        </div>
        <div className="todo-body">
          <div className="container-fluid">
            <div className="row">
              {array.map((item, index) => (
                <div className="col-lg-3 col-11 mx-lg-5 mx-3 my-2" key={index}>
                  <TodoCards
                    title={item.title}
                    body={item.body}
                    id={index}
                    delid={del}
                    display={(value) => {
                      if (value === "block") {
                        handleUpdate(index);
                      } else {
                        closeUpdate();
                      }
                    }}
                    toBeUpdate={() => handleUpdate(index)} // Function to handle updating
                    updateId={index} // Pass the index to be updated
                  />
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
      {isUpdating && (
        <div className="todo-update" id="todo-update">
          <div className="container update">
            <Update
              display={closeUpdate} // Pass the close function
              input={input} // Pass input to the Update component
              onUpdateTask={updateTask} // Function to handle task update
            />
          </div>
        </div>
      )}
    </>
  );
};

export default Todo;
