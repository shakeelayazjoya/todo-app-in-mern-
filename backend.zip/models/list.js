const mongoose = require("mongoose");

const listSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true,
  },
  body: {
    type: String,
    required: true,
  },
  user: {
    // Changed to a single reference
    type: mongoose.Types.ObjectId,
    ref: "User",
    required: true, // Ensuring that a user is always associated with a task
  },
});

module.exports = mongoose.model("List", listSchema);
