const router = require("express").Router();
const User = require("../models/user");
const List = require("../models/list");

// Add Task
router.post("/addTask", async (req, res) => {
  try {
    const { title, body, id } = req.body;
    const existingUser = await User.findById(id);

    if (existingUser) {
      const list = new List({ title, body, user: existingUser._id });
      await list.save();

      if (!existingUser.list) {
        existingUser.list = [];
      }

      existingUser.list.push(list._id);
      await existingUser.save();

      return res.status(200).json({ list });
    } else {
      return res.status(404).json({ message: "User not found." });
    }
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "Server error." });
  }
});

// Update Task
router.put("/updateTask/:id", async (req, res) => {
  try {
    const { title, body, email } = req.body;
    const existingUser = await User.findOne({ email });

    if (existingUser) {
      const updatedTask = await List.findByIdAndUpdate(
        req.params.id,
        { title, body },
        { new: true }
      );

      if (!updatedTask) {
        return res.status(404).json({ message: "Task not found." });
      }

      return res.status(200).json({ task: updatedTask });
    } else {
      return res.status(404).json({ message: "User not found." });
    }
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "Server error." });
  }
});

// Delete Task
router.delete("/deleteTask/:id", async (req, res) => {
  try {
    const { email } = req.body;
    const existingUser = await User.findOneAndUpdate(
      { email },
      { $pull: { list: req.params.id } },
      { new: true }
    );

    if (existingUser) {
      const deletedTask = await List.findByIdAndDelete(req.params.id);

      if (!deletedTask) {
        return res.status(404).json({ message: "Task not found." });
      }

      return res.status(200).json({ message: "Task deleted successfully." });
    } else {
      return res.status(404).json({ message: "User not found." });
    }
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "Server error." });
  }
});

// Get Tasks
router.get("/getTask/:id", async (req, res) => {
  try {
    const tasks = await List.find({ user: req.params.id }).sort({
      createdAt: -1,
    });

    if (tasks.length !== 0) {
      return res.status(200).json({ tasks });
    } else {
      return res.status(404).json({ message: "No tasks found." });
    }
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

module.exports = router;
