const router = require("express").Router();
const bcrypt = require("bcryptjs");

const User = require("../models/user");

// Signin (Register)
router.post("/register", async (req, res) => {
  try {
    const { username, email, password } = req.body;

    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(200).json({ message: "User already exists" });
    }

    const hashpassword = bcrypt.hashSync(password, 10);
    const newUser = new User({ username, email, password: hashpassword });
    await newUser.save();

    res
      .status(200)
      .json({ message: "User registered successfully", user: newUser });
  } catch (err) {
    res.status(500).json({ message: "An error occurred", error: err.message });
  }
});

// Login (Authenticate)
router.post("/login", async (req, res) => {
  try {
    const user = await User.findOne({ email: req.body.email });
    if (!user) {
      return res.status(400).json({ message: "User not found" });
    }

    const isPasswordCorrect = bcrypt.compareSync(
      req.body.password,
      user.password
    );
    if (!isPasswordCorrect) {
      return res.status(400).json({ message: "Password is incorrect" });
    }

    const { password, ...otherDetails } = user._doc;
    res.status(200).json({ message: "Login successful", user: otherDetails });
  } catch (err) {
    res.status(500).json({ message: "An error occurred", error: err.message });
  }
});

router.get("/users", async (req, res) => {
  try {
    const users = await User.find(); // Fetch all users from the User collection

    if (users.length !== 0) {
      res.status(200).json({ users }); // Return the users in the response
    } else {
      return res.status(404).json({ message: "No users found." });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
